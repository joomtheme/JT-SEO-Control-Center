JT SEO Control Center 1.0.69
Joomla 6 article SEO fields compatibility fix.

## 1.0.69

- Fixes missing JT SEO article fields on Joomla 6 by obtaining the form from PrepareFormEvent::getForm().
- Preserves compatibility with generic events using subject, form, or positional arguments.
- Fixes Joomla Web Asset URIs for dashboard and live-score JavaScript/CSS so these assets actually load.
- Loads the plugin XML by its absolute filename and adds live score assets only after successful loading.
- Enables the system and content plugins after a new package installation; preserves administrator-selected states during upgrades.
- Synchronizes all extension, asset, health-check and schema-marker versions to 1.0.69.

## 1.0.68

- Fixes fallback `Article` JSON-LD being suppressed when another script only referenced the Article `@id` without declaring an Article entity.
- Improves Joomla article detection for late-render/SEF Single Article menu routes so JT SEO still generates the Article node when Joomla core Schema.org output is disabled.
- Preserves explicitly selected Joomla core item schemas such as `Book`, `Event` and `Recipe` instead of replacing them with a fallback `Article`.
- Restores a selected Joomla core item schema from Joomla's `#__schemaorg` record if the base core graph is present but the item-level node is missing from the rendered JSON-LD.
- Keeps Joomla-rendered custom schema nodes intact when present, while continuing to enrich Joomla Article/NewsArticle/BlogPosting nodes with multilingual identity, absolute media URLs and publication/modification dates.
- Synchronizes package, component, plugin, asset and health-check versions to 1.0.68 and adds a database schema marker.

## 1.0.67

- Integrates with Joomla core Schema.org output by enhancing the native graph in place instead of publishing a competing second Article/WebPage graph.
- Ensures Joomla Article output contains `datePublished` from `publish_up` (falling back to `created`) and `dateModified` from `modified` (falling back to the publication date), independent of frontend date-display options.
- Converts Schema logo, `contentUrl`, `thumbnailUrl` and article image paths to absolute site-root URLs so multilingual routes cannot resolve images relative to the current page.
- Adds a dedicated global and per-language **Website name** used by `WebSite.name` and `og:site_name`, while keeping Organization/LocalBusiness name separate.
- Keeps the existing per-language Organization logo override and applies it to Joomla core and JT SEO structured data with global fallback.
- Preserves generic `WebPage` output for SP Page Builder and other non-article pages without inventing Article publication/modification dates.
- Improves compatibility with Joomla core Schema plugins: they may remain enabled; JT SEO enhances the Joomla core graph when detected and falls back to its own JSON-LD graph when core Schema is unavailable.
- Clarifies duplicate protection: JSON-LD duplicates are handled automatically, but Article Microdata (`itemscope`, `itemtype`, `itemprop`) embedded by a template is a separate representation. Templates should not output a second Article Microdata entity when JT SEO/Joomla JSON-LD Article output is used.
- Synchronizes package, component, plugin, asset and health-check versions to 1.0.67 and adds a database schema marker.

## 1.0.66

- Adds frontend JSON-LD output for Organization or LocalBusiness, WebSite, WebPage and Joomla Article pages.
- Adds dedicated homepage organization settings, including logo, contact details, PostalAddress and sameAs profile URLs.
- Adds generic WebPage schema for SP Page Builder and other non-article component pages without page-builder-specific coupling.
- Adds language-tag-based schema overrides for organization name, alternate name, description, logo, email, telephone and address values.
- Adds Article `dateModified` using Joomla's real modification date, with ISO 8601 output and publication-date fallback.
- Detects existing JSON-LD types and `@id` values before injection to reduce duplicate structured data.
- Uses the standards-based `Organization.logo` / `LocalBusiness.logo` property instead of the non-standard `og:logo`; the configured logo can also act as the standard `og:image` fallback.
- Synchronizes package, component, plugin and asset versions to 1.0.66 and adds a database schema marker.

## 1.0.65.3

- Fixes multilingual wildcard include/exclude matching so a rule such as `/mycotoxin/*` also matches language-prefixed URLs such as `/en/mycotoxin/...`.
- Keeps explicitly language-prefixed rules such as `/en/mycotoxin/*` scoped to that prefixed route.
- Synchronizes package, component, plugin and asset versions to 1.0.65.3.
- Removes the stale package-level `script.php` manifest reference instead of shipping an unnecessary installer script.
- Adds a 1.0.65.3 database schema marker.
- Improves Joomla Extension Directory checker compatibility.

## 1.0.65

- Adds configurable homepage and internal-page `changefreq` and `priority` values.
- Adds repeatable language-specific homepage overrides, including an optional manual `lastmod` date.
- Adds an option for homepage `lastmod` to inherit the newest published article date for the matching language.
- Adds Google image sitemap integration for Joomla article intro/full images and category images.
- Adds Excluded URLs and Included URLs rules with `*` and `?` wildcard support; include rules override noindex and exclude rules.
- Uses real child-sitemap content dates for sitemap-index `lastmod` instead of the generation date.
- Updates the browser stylesheet with an image count and image URL display.
- Updates package, component, plugin and asset versions to 1.0.65 and adds a schema marker.

## 1.0.64

- Excludes sitemap URLs that fall under Joomla menu items whose Robots setting contains `noindex` (for example `/tag` and `/tag/*`).
- Adds multilingual sitemap index output when multiple Joomla content languages are published.
- Adds language-specific paginated sitemap files such as `sitemap.en-GB.1.xml` and `sitemap.en-GB.2.xml`.
- Adds a configurable max links per sitemap file setting, defaulting to 10,000.
- Updates package, component, plugin and asset versions to 1.0.64.
- Adds a 1.0.64 schema marker.

## 1.0.61

- Reworked the dashboard health card wording so database readiness is shown as OK, not as misleading Active feature state.
- Added a separate 404 request logging health item that follows the real component option and correctly shows Active or Disabled.
- Made the 404 logger compatible with older upgraded tables even if the provisional column was not present yet.
- Tightened article/menu route validation so malformed direct article menu URLs such as /article-alias124 are not treated as successful routes.
- Added a 1.0.61 schema marker; script.php still performs guarded database repair for MySQL/MariaDB compatibility.

## 1.0.59
- Restored reliable provisional 404 capture for malformed article URLs that Joomla resolves before raising a late 404.
- Successful 2xx/3xx frontend responses now clean up the provisional row, while confirmed 404 responses keep and confirm it.
- Updated package/component/plugin, dashboard health and asset versions to 1.0.59.

## 1.0.58
- Fixed confirmed-only 404 logging so normal frontend page views no longer create provisional DB rows.
- Made 404 query-string, referrer and user-agent privacy options effective in the logger.
- Moved redirect delete/clear and 404 clear actions from tokenized GET links to POST forms.
- Tightened redirect controller permissions by using edit/delete permissions instead of only manage.
- Removed dashboard view side effects: opening the dashboard no longer writes /sitemap.xml automatically.
- Loaded the dashboard model through Joomla MVC instead of manually instantiating it in the view.
- Hardened sitemap article selection so private access levels are not exposed.
- Added uninstall language-file guards to reduce non-fatal File::delete warnings from older installs.
- Updated package/component/plugin and asset versions to 1.0.58.

## 1.0.57
- Improved Bulk Meta Manager UX with default "Needs attention" filtering, pagination and compact article rows.
- Collapsed CSV import/export tools so the editor opens cleaner on small and large sites.
- Moved robots, canonical and Open Graph image controls into per-article advanced sections.
- Added clearer bulk editing prompts and changed-field highlighting for safer editing.
- 404 logging records only confirmed route misses or 404 responses; it no longer writes provisional rows for every frontend request.
- Added privacy controls for 404 query-string and referrer logging.
- Added component description language string to normal admin/site language files for safer manifest translation.
- Cleaned SQL update marker comments and added a 1.0.57 schema marker.

## 1.0.53
- Dashboard tabs use Joomla core UI tabs.
- Structured Data JSON preview no longer creates page-level horizontal scrolling.
- GPL license copy added to the package and child extension archives.
- SQL update chain cleaned and component installer self-healing added to avoid duplicate-column errors on upgrades.
- Structured Data dashboard mapping messages moved to language strings.
- Content plugin asset loading now uses Joomla Web Asset Manager only.
- Privacy note added for 404 diagnostic logging.

## Privacy note
JT SEO Control Center can store 404 request URLs when 404 tracking is enabled. Referrer URLs, query strings and user-agent strings are controlled by separate options. This data is used for SEO diagnostics and redirect management. Site owners should disclose this behavior in their privacy policy where required.

## License
GNU General Public License version 2 or later. See LICENSE.txt.
